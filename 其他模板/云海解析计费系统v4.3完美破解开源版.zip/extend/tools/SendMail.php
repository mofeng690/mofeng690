<?php
namespace tools;
use PHPMailer\PHPMailer\PHPMailer;
use app\admin\model\Webpz;

class SendMail
{
    public function sendEmail($toemail,$zt,$content)
    {
        $webdata = Webpz::find(1);
        
        $email = new PHPMailer();
        //使用SMTP发送邮件
        $email->isSMTP();
        //调试模式
        $email->SMTPDebug = 0;
        //SMTP主机
        $email->Host = 'smtp.qq.com';
        //SMTP用户名
        $email->Username = $webdata->emailname;
        //SMTP密码
        $email->Password = $webdata->authcode;
        //设置邮件的发件人电子邮件地址
        $email->From = $webdata->emailname;
        //设置消息的主题。
        $email->Subject = $zt;
        //本消息正文
        $email->Body = $content;
        //smtp需要鉴权 这个必须是true
        $email->SMTPAuth = true;
        //在SMTP连接上使用哪种加密
        $email->SMTPSecure = 'ssl';
        //SMTP服务器端口
        $email->Port = 465;
        //设置发送人
        $email->setFrom($webdata->emailname,$webdata->name);
        //添加收件人地址
        $email->addAddress($toemail);
        //创建并发送消息
        $result = $email->send();
        if (!$result) {
            return false;
        }
        return true;
    }
}
