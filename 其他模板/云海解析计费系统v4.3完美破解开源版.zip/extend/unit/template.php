<?php
namespace unit;

class template
{
    public $path = "../view/home/template/";
    
    public function set($name){
        $cont = $this->path.$name.'/index.html';
        return $cont;
    }
    
    public function up($cont,$name){
        $text=stripslashes($cont);
        file_put_contents($this->path.$name.'/index.html',$text);
    }
}