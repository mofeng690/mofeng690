<?php
namespace pay\payFace;
use pay\payFace\src\Pay;

class payFace
{   
    public $config = [];
    
    public function __construct(){
        $this->config = json_decode(file_get_contents('../extend/pay/payFace/config.json'),true);
        $this->config['notifyUrl'] = 'https://'.Request()->host().'/home/index/notic';
    }
    
    public function creatOrder($ordersum,$price=0,$ordername='Service余额充值'){
        $alipay = new Pay($this->config);
        $data = [
            'outTradeNo' => $ordersum,     //商户订单号，需要保证唯一
            'totalFee'  => $price,           //订单金额，单位 元
            'orderName' => $ordername,      //订单标题
        ];
        $ret = $alipay->qrPay($data);     //扫码支付
        if($ret['alipay_trade_precreate_response']['code'] == 10000){
            return [true,$ret['alipay_trade_precreate_response']['out_trade_no'],$ret['alipay_trade_precreate_response']['qr_code']];
        }else{
            return [false,'订单创建失败'];
        }
    }
    
    public function notify($res){
        $alipay = new Pay($this->config);
        $ret = $alipay->rsaCheck($res);  //notify数据验签
        return $ret;
    }
    
    
    
    /***.   校验示例
     *     if(Request()->isPost()){
     *       
            $os = new PayFace();
            $res = $os->notify($_POST);
            需查询系统中是否存在该订单号 价格是否对应
            $_POST['out_trade_no'];
            $_POST['total_amount'];
            if($res){
               file_put_contents('log.txt',1);    
            }else{
               file_put_contents('log.txt',0);
            }
        }
     * */
}
