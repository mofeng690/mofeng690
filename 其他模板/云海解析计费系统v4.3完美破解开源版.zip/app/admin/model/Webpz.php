<?php

namespace app\admin\model;

use think\Model;
/**
 * 
 */
class Webpz extends Model
{
	
}