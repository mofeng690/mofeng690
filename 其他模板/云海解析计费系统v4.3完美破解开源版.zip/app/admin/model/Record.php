<?php

namespace app\admin\model;

use think\Model;
/**
 * 
 */
class Record extends Model
{
	
}