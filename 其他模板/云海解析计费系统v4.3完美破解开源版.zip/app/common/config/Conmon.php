<?php
namespace app\common\config;

class Conmon
{

    
}
