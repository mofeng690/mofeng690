<?php
namespace app\api\controller;
use app\user\model\Business;
use app\admin\model\Record;
use think\facade\Db;

class Index 
{
    public function index()
    {
        return '阿奇源码网计费系统 轮询文件';
    }
    
    public function emptyday()
    {
        //一天一清理
        $r = Business::where('id','<>',0)->update(['calltoday' => 0]);
        return '清理成功';
    }
    
    public function delre()
    {
        //可自由定义清理时间 
        Db::query('truncate table yh_record');
        return '清理成功';
    }
    
}