<?php
namespace app\home\controller;

use app\admin\model\Webpz;
use app\admin\model\Record;
use app\admin\model\Replace;
use app\user\model\Business;
use app\admin\model\Information;
use app\admin\model\Order;
use app\user\model\User;

/**
 * note: Api模块
 */
class Api
{
     public static $jiexi="0";
     
    public function index()
    {
        global  $key;
        $url = input('param.url');
        $type = input('param.type');
        $ip = input('param.ip');
        if (empty($ip)) {
            $ip = $_SERVER["REMOTE_ADDR"];
        }
        $uid = input('param.uid');
        $key = input('param.key');
        $data = file_get_contents('php://input');
        $data = json_decode($data, true);
        if ($data) {
            $uid = $data['uid'];
            $key=$data['key'];
        }
        if ($uid=='' || $key=='') {
            return '请检查您的信息';
        }
        $yw = new Business;
        $userinfo = $yw->where('user_uid', $uid)->find();
        if ($userinfo['user_key']!=$key) {
            $data=['code' => 300,'msg'=>'uid和秘钥不匹配！'];
            return json($data);
        }
        if ($url == '') {
            return '【温馨提示:请输入url网址解析】系统:觅知云海v4.3解析计费系统,官方网址：http://aqiyuanma.com/，云海v4.3解析计费系统下载：https://www.aqiyuanma.com/2976.html';
        }
        $byurl = $url;
        if ($userinfo->type==1) {
            if ($userinfo->surplus<2) {//解析一次扣两点
                $data=['code' => 300,'msg'=>'点数已用尽请及时续费！赞助得点数：QQ->www.aqiyuanma.com'];
                return json($data);
            }
            if ($userinfo->limitnum!=0 && $userinfo->calltoday >= $userinfo->limitnum) {
                $data=['code' => 300,'msg'=>'今日调用已经超过限制！'];
                return json($data);
            }
            $userinfo->calltoday = $userinfo->calltoday+1;
        } else {
            if ($userinfo->surplus<=time()) {
                $data=['status' => 300,'msg'=>'包月已经到期,请及时续费！'];
                return json($data);
            }
            if ($userinfo->limitnum!=0 && $userinfo->calltoday >= $userinfo->limitnum) {
                $data=['code' => 300,'msg'=>'今日调用已经超过限制！'];
                return json($data);
            }
            $userinfo->calltoday = $userinfo->calltoday+1;
        }
        $webpz = Webpz::find(1);
        if ($webpz->th==1) {
            $newurl = $this->replace($url);
        }
        if ($newurl) {
            $data = [
                'code'  => 200,
                'msg'   => 'success',
                'type'  => 'mp4',
                'player'=> 'dplayer',
                'url'   => $newurl,
                ];
        } else {
            $px = 1; // 值为"1"则先走所设置api,值为"2"先走资源网 全局最优先替换资源库
            if ($px==1) {
               $data = $this->apijx($type,$url);
           
               if ($data['code']==404) {
                   $jiexi="https://vip.shuangyuer.xyz/api/?key=LRgocxCZhMdklpEjkG&url=";//设置备用资源库或者备用json接口1
                   
                    $data = $this->yunsearch($jiexi,$byurl);
                    if($data['code']==404){
                        $jiexi="https://jx.zhuiya.vip/api/?key=RehOosQPpgUHkwtEBk&url=";//设置备用资源库或者备用json接口2
                        $data = $this->yunsearch($jiexi,$byurl);
                    }
                }
            } else {
                $jiexi="https://vip.shuangyuer.xyz/api/?key=LRgocxCZhMdklpEjkG&url=";//设置备用资源库或者备用json接口3
               
                $data = $this->yunsearch($jiexi,$byurl);
                if ($data['code']==404) {
                     $jiexi="https://jx.zhuiya.vip/api/?key=RehOosQPpgUHkwtEBk&url=";//设置备用资源库或者备用json接口4
                    $data = $this->yunsearch($jiexi,$byurl);
                }
            }
        }
        
        
        if ($data['code']==200 && $userinfo->type==1) {
            $userinfo->surplus = $userinfo->surplus-2;//解析扣的点数
        }
        $userinfo->save();
        $re = new Record;
        $re->url = $byurl;
        $re->ip  = $ip;
        // $jsonips = posturl("http://aqiyuanma.com/ips/ips.php?ip=".$ip,"");
        
        $jsonips = posturl($_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/ips/ips.php?ip=".$ip,"");
        $re->ipaddr  = $jsonips['address'];
        if($jsonips['address']==null){
        //$jsonips = posturl("http://aqiyuanma.com/ips/ipst.php?ip=$ip");
        $jsonips = posturl($_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/ips/ipst.php?ip=".$ip,"");
        }
        if($jsonips['address']==null){
            $re->ipaddr  = "阿奇源码网定位系统异常";
        }else{
            $re->ipaddr  = $jsonips['address'];
        }
        
        $re->uid = $uid;

        if ($data['code']==200) {
            $re->status = 1;
        } else {
            $re->status = 0;
        }
        $re->intime = time();
        $re->save();
      
        if($type=="hezi" && $data['code']==200){
              header('Location:'.$data['url']);//跳转到带www的网址
        }else if($type=="ckplayer" && $data['code']==200){
			$ckplayer = $webpz->ckbfq;
              header('Location:'.$ckplayer.$data['url']);//跳转到带www的网址
        }else if($type=="h5player" && $data['code']==200){
			$h5player = $webpz->h5bfq;
              header('Location:'.$h5player.$data['url']);//跳转到带www的网址
        }else if($type=="dplayer" && $data['code']==200){
			$dplayer = $webpz->dbfq;
              header('Location:'.$dplayer.$data['url']);//跳转到带www的网址
        }
        return jsondata($data);
    }
    
    public function apijx($type,$url)
    {
        $webpz = Webpz::find(1);
        if ($type=='ys') {
            $api = $webpz->api;
            $apione = $webpz->apione;
            $apitwo = $webpz->apitwo;
            $urlone = "$api".$url;

            $json = posturl($urlone,"");

            if ($json['code']==200 && $json['url']!=''&& strpos($json['url'],'.') !== false) {


                                 $data = [
                                'code'  => $json['code'],
                                'msg'   => "阿奇源码网直解系统线路一",
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                    ];
                  }
            else {
                        
              $urltwo = "$apione".$url;
              $json = posturl($urltwo, '');
              
         
            if ($json['code']==200 && $json['url']!='') {

		
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => "阿奇源码网直解系统线路二",
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        
            $urlthree = "$apitwo".$url;
            $json = posturl($urlthree, '');
        
            if ($json['code']==200 && $json['url']!='') {

			
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => "阿奇源码网直解系统线路三",
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        $data = [
                                'code' => 404,
                                'msg'  => 'dsp未能成功获取到该资源,'
                                ];
                       
                        
                    }
                        
                    }
                        
                        
                        
            }
        } 
        else  if ($type=='hezi') {
            $api = $webpz->api;
            $apione = $webpz->apione;
            $apitwo = $webpz->apitwo;
            $urlone = "$api".$url;

            $json = posturl($urlone,"");

            if ($json['code']==200 && $json['url']!=''&& strpos($json['url'],'.') !== false) {


                                 $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路一',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                    ];
                  }
            else {
                        
              $urltwo = "$apione".$url;
              $json = posturl($urltwo, '');
              
         
            if ($json['code']==200 && $json['url']!='') {

		
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路二',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        
            $urlthree = "$apitwo".$url;
            $json = posturl($urlthree, '');
        
            if ($json['code']==200 && $json['url']!='') {

			
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路三',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        $data = [
                                'code' => 404,
                                'msg'  => 'dsp未能成功获取到该资源,'
                                ];
                       
                        
                    }
                        
                    }
                        
                        
                        
            }
        } 
        else  if ($type=='ckplayer') {
            $api = $webpz->api;
            $apione = $webpz->apione;
            $apitwo = $webpz->apitwo;
            $urlone = "$api".$url;

            $json = posturl($urlone,"");

            if ($json['code']==200 && $json['url']!=''&& strpos($json['url'],'.') !== false) {


                                 $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路一',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                    ];
                  }
            else {
                        
              $urltwo = "$apione".$url;
              $json = posturl($urltwo, '');
              
         
            if ($json['code']==200 && $json['url']!='') {

		
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路二',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        
            $urlthree = "$apitwo".$url;
            $json = posturl($urlthree, '');
        
            if ($json['code']==200 && $json['url']!='') {

			
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路三',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        $data = [
                                'code' => 404,
                                'msg'  => 'dsp未能成功获取到该资源,'
                                ];
                       
                        
                    }
                        
                    }
                        
                        
                        
            }
        } 
        else  if ($type=='h5player') {
            $api = $webpz->api;
            $apione = $webpz->apione;
            $apitwo = $webpz->apitwo;
            $urlone = "$api".$url;

            $json = posturl($urlone,"");

            if ($json['code']==200 && $json['url']!=''&& strpos($json['url'],'.') !== false) {


                                 $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路一',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                    ];
                  }
            else {
                        
              $urltwo = "$apione".$url;
              $json = posturl($urltwo, '');
              
         
            if ($json['code']==200 && $json['url']!='') {

		
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路二',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        
            $urlthree = "$apitwo".$url;
            $json = posturl($urlthree, '');
        
            if ($json['code']==200 && $json['url']!='') {

			
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路三',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        $data = [
                                'code' => 404,
                                'msg'  => 'dsp未能成功获取到该资源,'
                                ];
                       
                        
                    }
                        
                    }
                        
                        
                        
            }
        } 
        else  if ($type=='dplayer') {
            $api = $webpz->api;
            $apione = $webpz->apione;
            $apitwo = $webpz->apitwo;
            $urlone = "$api".$url;

            $json = posturl($urlone,"");

            if ($json['code']==200 && $json['url']!=''&& strpos($json['url'],'.') !== false) {


                                 $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路一',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                    ];
                  }
            else {
                        
              $urltwo = "$apione".$url;
              $json = posturl($urltwo, '');
              
         
            if ($json['code']==200 && $json['url']!='') {

		
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路二',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        
            $urlthree = "$apitwo".$url;
            $json = posturl($urlthree, '');
        
            if ($json['code']==200 && $json['url']!='') {

			
                     $data = [
                                'code'  => $json['code'],
                                'msg'   => '阿奇源码网直解系统线路三',
                                'type'  => 'm3u8',
                                'player'=> "dplayer",
                                'url'   => $json['url'],
                            ];
                    } else {
                        $data = [
                                'code' => 404,
                                'msg'  => 'dsp未能成功获取到该资源,'
                                ];
                       
                        
                    }
                        
                    }
                        
                        
                        
            }
        } 
        else {
            $api = $webpz->dspapi;
            $url = $api.$url;
            $json = posturl($url, '');
            if($json['status']==101){
                $data = [
                    'code'  => 200,
                    'type'  => '直链',
                    'player'=> 'ckplayer',
                    'url'   => $json['data']['url'],
                    ];
            }else{
                $data = [
                    'code' => 404,
                    'msg'  => '解析失败,'
                    ];
            }
        }
        return $data;
    }
    
    public function replace($url)
    {
        $tx="v.qq.com/x/cover/";
        $txgz="v.qq.com/x/page/";
        $txsj="m.v.qq.com/x/m/";
        $aqy="iqiyi.com";
        $yk="youku.com/v_show/";
        $mg="mgtv.com/b/";
        $tx2="qq.com/x/m/play";
        $m1905="1905.com/play/";
        $le="le.com/ptv/vplay/";
        $array=explode('://', $url);
        $tg = '';
        if (stripos($url, $tx)) {
            $url=$array[1];
            $sz=explode('qq.com/x/cover/', $url);
            $url=$sz[1];
            $pt='腾讯视频 pc';
        } elseif (stripos($url, $txsj)) {
            if (stripos($url, $tx2)) {
                $url=$array[1];
            } else {
                $url=$array[1];
                $sz=explode('qq.com/x/m/', $url);
                $url=$sz[1];
                $pt='腾讯视频 手机';
            }
        } elseif (stripos($url, $aqy)) {
            $url=$array[1];
            $sz=explode('/', $url);
            $fss=explode('html', $sz[1]);
            $url=$fss[0].'html';
            $pt='爱奇艺';
        } elseif (stripos($url, $yk)) {
            $url=$array[1];
            $sz=explode('youku.com/v_show/', $url);
            $fss=explode('html', $sz[1]);
            $url=$fss[0].'html';
            $pt='优酷';
        } elseif (stripos($url, $txgz)) {
            $url=$array[1];
            $sz=explode('qq.com/x/page/', $url);
            $url=$sz[1];
            $pt='腾讯视频';
        } elseif (stripos($url, $mg)) {
            $url=$array[1];
            $sz=explode('mgtv.com/b/', $url);
            $fss=explode('html', $sz[1]);
            $url=$fss[0].'html';
            $pt='芒果tv';
        } elseif (stripos($url, $m1905)) {
            $url=$array[1];
            $sz=explode('1905.com/play/', $url);
            $fss=explode('shtml', $sz[1]);
            $url=$fss[0].'shtml';
            $pt='1905电影网';
        } elseif (stripos($url, $le)) {
            $url=$array[1];
            $sz=explode('le.com/ptv/vplay/', $url);
            $fss=explode('html', $sz[1]);
            $url=$fss[0].'html';
            $pt='乐视';
        } else {
            $tg=1;
        }
        $newurl = Replace::where('url', 'like', '%'.$url.'%')->where(['status'=> 1])->value('newurl');
        return $newurl;
    }
    
    public function yunsearch($jiexi,$byurl)
    {
        $url = $jiexi.$byurl;
        $data = posturl($url, '');
        if($data['code']==200){
        $data = [
                        'code'  => $data['code'],
                        'msg'   => '阿奇源码网直解系统线路四',//"success",
                        'type'  => 'mp4',
                        'player'=> 'dplayer',
                        'url'   => $data['url'],
        ];
        }else{
             $data = [
                    'code' => 404,
                    'msg'  => '未找到该资源,'
                    ];
        }
        return $data;
    }
    
    public function returnPayment()
    {
        $data = input('get.');
        $Information = Information::find(1);
        ksort($data);
        reset($data);
        $codepay_key = $Information->zfkey;
        $sign = '';
        foreach ($data as $key => $val) {
            if ($val == '' || $key == 'sign') {
                continue;
            }
            if ($sign) {
                $sign .= '&';
            }
            $sign .= "$key=$val";
        }
        if (!input('get.pay_no') || md5($sign . $codepay_key) != input('get.sign')) {
            exit('fail');
        } else {
            $pay_id = input('get.pay_id');
            $money = input('get.money');
            $price = input('get.price');
            $param = input('get.param');
            $pay_no = input('get.pay_no');
            $pay = Order::find($param);
            if ($pay->status==1) {
                return redirect('/user/?type=success&msg=充值成功');
                die();
            }
            $pay->payment    = $money;
            if ($price == $money) {
                $pay->status = 1;
            } else {
                $pay->status = 2;
            }
            $pay->save();
            $user = User::where('username', $pay_id)->find();
            $user->balance = $money + $user->balance;
            $user->save();
            return redirect('/user/?type=success&msg=充值成功');
        }
    }
    
    public function verifyPayment()
    {
        $data = input('post.');
        $Information = Information::find(1);
        ksort($data);
        reset($data);
        $codepay_key = $Information->zfkey;
        $sign = '';
        foreach ($data as $key => $val) {
            if ($val == '' || $key == 'sign') {
                continue;
            }
            if ($sign) {
                $sign .= '&';
            }
            $sign .= "$key=$val";
        }
        if (!input('post.pay_no') || md5($sign . $codepay_key) != input('post.sign')) {
            exit('fail');
        } else {
            $pay_id = input('post.pay_id');
            $money = input('post.money');
            $price = input('post.price');
            $param = input('post.param');
            $pay_no = input('post.pay_no');
            $pay = Order::find($param);
            $pay->payment    = $money;
            if ($price == $money) {
                $pay->status = 1;
            } else {
                $pay->status = 2;
            }
            $pay->save();
            $user = User::where('username', $pay_id)->find();
            $user->balance = $money + $user->balance;
            $user->save();
            exit('success');
        }
    }
    
    public function posturl($url,$data1="")
    {
       
    $curl = curl_init();
    //1.初始化，创建一个新cURL资源
    $UserAgent = 'Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36';
    curl_setopt($curl, CURLOPT_URL, $url);
    //2.设置URL curl_setopt($ch, CURLOPT_URL, "http://www.lampbrother.net/");
    // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_TIMEOUT, 5);
    //在发起连接前等待的时间，如果设置为0，则无限等待。
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //设定是否显示头信息
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    //启用时会将服务器服务器返回的"Location: "放在header中递归的返回给服务器,设置可以302跳转
    curl_setopt($curl, CURLOPT_REFERER, "http://aqiyuanma.com/");
    //构造来路
    curl_setopt($curl, CURLOPT_USERAGENT, $UserAgent);
    curl_setopt($curl, CURLOPT_ENCODING, 'gzip,deflate');
    //gzip压缩内容
    $data = curl_exec($curl);
    // 抓取URL并把它传递给浏览器
    curl_close($curl);
    return $data;
        
        
    }

}
