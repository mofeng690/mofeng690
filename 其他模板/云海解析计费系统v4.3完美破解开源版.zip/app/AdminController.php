<?php

namespace app;

use think\App;
use think\exception\ValidateException;
use think\Validate;
use think\facade\Db;
use think\facade\View;
abstract class AdminController
{
    protected $request;
    protected $app;
    protected $batchValidate = false;
    protected $middleware = [];
    public $dn = 'www.1080dyw.com:521';
    public function __construct(App $app)
    {
        $this->app = $app;
        $this->request = $this->app->request;
        $adminid = session('admin');
        if (!$adminid) {
            header('location: /admin/login');
            die;
        } else {
            $admin = Db::name('admin')->where('id', $adminid)->find();
            $this->admin = $admin;
        }
        $this->initialize();
    }
    protected function initialize()
    {
        $web = Db::name('webpz')->where('id', 8)->find();
        $this->web = $web;
        view::assign(['admin' => $this->admin, 'webtitle' => $web['name'], 'qq' => $web['qq'], 'qun' => $web['qun'], 'keyword' => $web['keyword'], 'contents' => $web['contents'], 'khdurl' => $web['khdurl'], 'tep' => $web['tep'], 'lbtgg' => $web['lbtgg']]);
    }
    protected function validate(array $data, $validate, array $message = [], bool $batch = false)
    {
        if (is_array($validate)) {
            $v = new Validate();
            $v->rule($validate);
        } else {
            if (strpos($validate, '.')) {
                [$validate, $scene] = explode('.', $validate);
            }
            $class = false !== strpos($validate, '\\') ? $validate : $this->app->parseClass('validate', $validate);
            $v = new $class();
            if (!empty($scene)) {
                $v->scene($scene);
            }
        }
        session('jifei', $data);
    }
}