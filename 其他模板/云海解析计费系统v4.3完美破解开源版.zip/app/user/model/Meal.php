<?php

namespace app\user\model;

use think\Model;
/**
 * 
 */
class Meal extends Model
{
	
}