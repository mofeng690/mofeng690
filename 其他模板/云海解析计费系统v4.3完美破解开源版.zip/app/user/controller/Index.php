<?php

namespace app\user\controller;

use think\facade\View;
use app\BaseController;
use app\admin\model\Information;
use app\admin\model\Record;
use app\user\model\User;
use app\user\model\Business;
use app\admin\model\Webpz;
/**
 * note:用户后台
 */
class Index extends BaseController
{

	public function index()
	{
            if($this->userinfo['type']==1){
            	$b = $this->userinfo['surplus'];
            	if($b<=100){
            	    $b = '<font color="red">'.$b.'</font>';
            	}
            }else{
            	$time = $this->userinfo['surplus'];
            	$b = timeDiff(time(),$time);
            	$b = $b['day'];
            	if($b<=2){
            	    $b = '<font color="red">'.$b.'</font>';
            	}
            }
            $time = date('Y-m-d');
            $utime = strtotime($time);
            $num = Record::where('uid',$this->userinfo['user_uid'])->where('intime','>',$utime)->count();
            $numall = Record::where('uid',$this->userinfo['user_uid'])->count();
            $Information = Information::find(1);
            $config = Webpz::find(1);
			view::assign([
				'title'		=> '用户首页',
				'notice'	=> $Information->notice,
				'tanchuang'	=> $config->tanchuang,
	          	'daydy' 	=> $num,  //今日调用
	          	'calltoday'	    => Business::where('user_uid',$this->userinfo['user_uid'])->value('calltoday'),
	          	'fstype'	=> $this->userinfo['type'],
	          	'useruid'	=> $this->userinfo['user_uid'],
			    'userkey'	=> $this->userinfo['user_key'],
	          	'surplus' 	=> $b, //剩余业务
	          	'jsonjx'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=ys&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
	          	'jsonjxtest'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=ys&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.qq.com/x/cover/mzc00200y4wycre/n0039grgi7h.html',
	          	'jiexi'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=hezi&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
			    'jxtext'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=hezi&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.qq.com/x/cover/mzc00200y4wycre/n0039grgi7h.html',
			    
	          	'jsonck'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=ckplayer&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
			    'jsonckcs'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=ckplayer&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.qq.com/x/cover/mzc00200y4wycre/n0039grgi7h.html',
			    
	          	'jsond'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=dplayer&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
			    'jsondcs'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=dplayer&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.qq.com/x/cover/mzc00200y4wycre/n0039grgi7h.html',
			    
	          	'jsonh5'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=h5player&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
			    'jsonh5cs'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=h5player&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.qq.com/x/cover/mzc00200y4wycre/n0039grgi7h.html',		
	            'jsondsp'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=dsp&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=',
	          	'jsondspcs'=> 'http://'.$_SERVER['HTTP_HOST'].'/home/api?type=dsp&uid='.$this->userinfo['user_uid'].'&key='.$this->userinfo['user_key'].'&url=https://v.douyin.com/Jy2avQm/',	
	          	'money'		=> $this->user['balance'],	//余额
	          	'status'	=> $this->user['status'],//账号状态
	          	
			]);
		return view();
	}
		public function replaceKey()
	{
			$userModel = new Business;
			$id = $this->user['id'];
			$key = $this->mystr(18);
			$userModel->where('id',$id)->update(['user_key' => $key]);
			return redirect('/user/index?type=success&msg=更换成功');
	}
		public function mystr($length)
    {
		$chars = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 
		    'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r', 's', 
		    't', 'u', 'v', 'w', 'x', 'y','z', 'A', 'B', 'C', 'D', 
		    'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M', 'N', 'O', 
		    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y','Z', 
		    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
		$keys = array_rand($chars, $length); 
		$my = '';
	    for($i = 0; $i < $length; $i++)
	    {
	        // 将 $length 个数组元素连接成字符串
	        $my .= $chars[$keys[$i]];
	    }
	    return $my;
    }
}