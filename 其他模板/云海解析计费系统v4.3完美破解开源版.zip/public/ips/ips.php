<?php
include 'Snoopy.class.php';

function httpget($url) {
    $curl = curl_init();
    //1.初始化，创建一个新cURL资源
    $UserAgent = 'Mozilla/6.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36';
    curl_setopt($curl, CURLOPT_URL, $url);
    //2.设置URL curl_setopt($ch, CURLOPT_URL, "http://www.lampbrother.net/");
    // 设置超时限制防止死循环
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    //在发起连接前等待的时间，如果设置为0，则无限等待。
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    //设定是否显示头信息
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    //启用时会将服务器服务器返回的"Location: "放在header中递归的返回给服务器,设置可以302跳转
    curl_setopt($curl, CURLOPT_REFERER, "http://www.gov.com");
    //构造来路
    curl_setopt($curl, CURLOPT_USERAGENT, $UserAgent);
    curl_setopt($curl, CURLOPT_ENCODING, 'gzip,deflate');
    //gzip压缩内容
    $data = curl_exec($curl);
    // 抓取URL并把它传递给浏览器
    curl_close($curl);
    return $data;
}




function xianlu ($xianlu,$xl){
    global  $arr;
    $str = httpget($xianlu);
    $jx = json_decode($str, true);

     if($jx["code"]==1||$jx["msg"]=="ok"){
        $arr = array(
            'code' => 200,
            'ip' => $jx["ip"],
            'lat' =>$jx['data']["location"]['lat'],
            'lng' =>$jx['data']["location"]['lng'],
            'address' =>$jx['data']["area"],
            'msg' =>"阿奇源码网定位系统",
            'title' =>"官网：http://aqiyuanma.com/",
            ); 
     }else{
       $arr = array(
            'code' => 404,
            'ip' => $_GET['ip'],
            'msg' =>"阿奇源码网定位系统",
            'title' =>"官网：http://aqiyuanma.com/",
            ); 
     }

   return $arr;
    
}



function getIP(){
        global $ip;
        if(getenv("HTTP_CLIENT_IP"))
        $ip=getenv("HTTP_CLIENT_IP");
        else if(getenv("HTTP_X_FORWARDED_FOR"))
        $ip=getenv("HTTP_X_FORWARDED_FOR");
        else if(getenv("REMOTE_ADDR"))
        $ip=getenv("REMOTE_ADDR");
        else $ip="NULL";
        return $ip;
        }
        
        
        
if($_GET['ip']==null){
            $ip=getIP();
}else{
            $ip=$_GET['ip'];
        }
        
        
$dzurl="https://www.toolnb.com/Tools/Api/ipgetareainfo.html?ip=$ip";

$arr=xianlu ($dzurl,"线路一");


echo json_encode($arr, JSON_NUMERIC_CHECK | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);  
?>