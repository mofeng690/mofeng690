<?php
ini_set("error_reporting","E_ALL & ~E_NOTICE");
$out_trade_no = $_GET['out_trade_no'];//商户订单号
$type = $_GET['type'];//支付方式 ：微信支付为wxpay 支付宝支付为alipay
$name = $_GET['name'];//商品名称
$money = $_GET['money'];//订单金额
$reallyPrice = $_GET['reallyPrice'];//实际支付金额
$trade_status = $_GET['trade_status'];//支付状态
$text = $_GET['text'];//通知文案
$grd = $_GET['grd'];//转跳地址
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="zh-cn">
    <meta name="apple-mobile-web-app-capable" content="no"/>
    <meta name="apple-touch-fullscreen" content="yes"/>
    <meta name="format-detection" content="telephone=no,email=no"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="white">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>支付详情</title>
    <link href="./css/wechat_pay.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" type="text/css" media="screen" href="css/font-awesome.min.css">
    <style>
        .text-success {
            color: #468847;
            font-size: 2.33333333em;
        }

        .text-fail {
            color: #ff0c13;
            font-size: 2.33333333em;
        }

        .text-center {
            text-align: center;
        }

        .text-left {
            text-align: left;
        }

        .error {

            display: block;
            padding: 9.5px;
            margin: 0 0 10px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #333;
            word-break: break-all;
            word-wrap: break-word;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 4px;

        }
    </style>
</head>

<body>
<div class="body">
    <h1 class="mod-title">
        <span class="ico_log ico-<?=($type != 'wxpay' ? '1' : '3')?>"></span>
    </h1>

    <div class="mod-ct">
        <div class="order">
        </div>
        <div class="amount">￥<?=$reallyPrice?></div>
        
        <div class='error text-left'><h1 class="text-center text-<?=($trade_status != 'TRADE_SUCCESS' ? 'fail' : 'success')?>"><?=($text != '' ? $text : '通知文案')?><strong></strong></h1><!--fail-success--></div>
        <div class="detail detail-open" style="display: block;">
            <dl class="detail-ct">
                <dt>商户订单号：</dt>
                <dd><?=$out_trade_no?></dd>
                <dt>支付方式：</dt>
                <dd><?=($type != 'wxpay' ? '支付宝' : '微信')?></dd>
                <dt>商品名称：</dt>
                <dd><?=$name?></dd>
                <dt>订单金额：</dt>
                <dd><?=$money?></dd>
                <dt>实际支付金额</dt>
                <dd><?=$reallyPrice?></dd>
                <dt>状态</dt>
                <dd><?=($trade_status != 'TRADE_SUCCESS' ? '支付失败' : '支付成功')?></dd>
            </dl>


        </div>

        <div class="tip-text">
        </div>


    </div>
    <div class="foot">
        <div class="inner">
            <p>如未到账请联系我们</p>
            <p>您将在<span id="second"></span>秒后自动跳转到 <a href="<?=($grd != '' ? $grd : '#')?>"><span id="link">无需等待，点击进入</span></a> </p>
            <p>本站源码由<a href="//www.a8ku.cn/" target="_blank" style="color:#5FB878">Mr.H</a>提供技术服务支持</p>
        </div>
    </div>

</div>
<script>
	var time = 3;//转跳时间
	function upTime(){
		document.querySelector('#second').innerHTML = time;
		time--;
		if(time == 0){
			document.querySelector('#link').click();
			clearInterval(timer)
		}
	}
	timer = setInterval('upTime()',1000)
</script>
</body>
</html>
