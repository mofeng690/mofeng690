<?php
/* * 
 * 功能：彩虹易支付页面跳转同步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。

 *************************页面功能说明*************************
 * 该页面可在本机电脑测试
 * 可放入HTML等美化页面的代码、商户业务逻辑程序代码
 * 该页面可以使用PHP开发工具调试，也可以使用写文本函数logResult，该函数已被默认关闭，见epay_notify_class.php中的函数verifyReturn
 */
require_once("epay.config.php");
require_once("db.class.php");
require_once("lib/epay_notify.class.php");

?>
<!DOCTYPE HTML>
<html>
    <head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?php
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyReturn();
if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代码
	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
    //获取支付宝的通知返回参数，可参考技术文档中页面跳转同步通知参数列表

	//商户订单号

	 $out_trade_no = $_GET['out_trade_no'];

	//支付宝交易号

	 $trade_no = $_GET['trade_no'];
     $money = $_GET['money'];
     $pid = $_GET['pid'];
     $name = $_GET['name'];
     $sitename = "Mr.H解析系统";
     $money = $_GET['money'];
     $user  =$username;
	//交易状态
	$trade_status = $_GET['trade_status'];
    $usedate = date("Y-m-d H:i:s");
	//支付方式
	$type = $_GET['type'];
if($type=="wxpay"){
  
    $paytype="微信";
}else if($type=="qqpay"){
   $paytype="QQ钱包"; 
}else{
    $paytype="支付宝";  
}

    if($trade_status=="TRADE_SUCCESS"){

DB::connect($dbconfig['host'],$dbconfig['user'],$dbconfig['pwd'],$dbconfig['dbname'],$dbconfig['port']);
$yhorder=DB::get_row("SELECT * FROM yh_order WHERE ordernum=$out_trade_no limit 1");
$money=$_GET['money'];	
$userid=$yhorder['user_id'];
$yhuser=DB::get_row("SELECT * FROM yh_user WHERE id=$userid");

$status=$yhorder['status'];
if($status==0){
    
DB::query("update yh_order set status=1 where ordernum=$out_trade_no");    
DB::query("update yh_user set balance=balance+$money where id=$userid");//改变用户额度    
}
else{
     header("refresh:3;url=finishbuy.php");
    
}
 header("refresh:3;url=../user/");




?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="zh-cn">
    <meta name="apple-mobile-web-app-capable" content="no"/>
    <meta name="apple-touch-fullscreen" content="yes"/>
    <meta name="format-detection" content="telephone=no,email=no"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="white">
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-control" content="no-cache">
    <meta http-equiv="Cache" content="no-cache">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>支付结果</title>
    <link href="pay/css/wechat_pay.css" rel="stylesheet" media="screen">
    <script src="pay/js/jquery.min.js"></script>
    <style>
        .text-success {
            color: #468847;
            font-size: 2.33333333em;
        }

        .text-fail {
            color: #ff0c13;
            font-size: 2.33333333em;
        }

        .text-center {
            text-align: center;
        }

        .text-left {
            text-align: left;
        }

        .error {

            display: block;
            padding: 9.5px;
            margin: 0 0 10px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #333;
            word-break: break-all;
            word-wrap: break-word;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 4px;

        }
    </style>
</head>

<body>
<div class="body" id="body">
    <h1 class="mod-title">
        <span class="ico_log ico-2" v-if="payType == 3"></span>
        <span class="ico_log ico-1" v-if="payType == 2"></span>
        <span class="ico_log ico-3" v-if="payType == 1"></span>
    </h1>

    <div class="mod-ct">
        <div class="order">
        </div>
        
        <div class='error text-left'><h1 class="text-center text-success">交易付款成功</h1><!--fail-success--></div>
        <div class="detail detail-open" style="display: block;">
            <dl class="detail-ct" id="desc" >
                <dt>商户订单号：</dt>
                <dd><?php echo $out_trade_no?></dd>
                <dt>支付方式：</dt>
                <dd><?php echo $paytype?></dd>
                <dt>商品名称：</dt>
                <dd><?php echo $name?></dd>
                <dt>订单金额：</dt>
                <dd><?php echo $money?></dd>
            </dl>


        </div>

        <div class="tip-text">
        </div>
 <div class='error text-left'><h3 class="text-center text-success" style="font-size:24px">用户：<?php echo $user?> 成功充值 <?php echo $money?> 人民币<br>正在转跳中，请稍等...</h3><!--fail-success--></div>
                <br />

    </div>
    <div class="foot">
        <div class="inner">
            <p>如有问题，请联系客服</p>
            <p>本站源码由<a href="//www.a8ku.cn/" target="_blank" style="color:#5FB878">Mr.H</a>提供技术服务支持</p>
        </div>
    </div>

</div>

<script src="./js/vue.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@1.11.3"></script>
<script src="https://lib.baomitu.com/layer/3.1.1/layer.js"></script>

</body>
</html>

<?php
    }else{
        
    }
 

	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    //如要调试，请看alipay_notify.php页面的verifyReturn函数
    echo "验证失败";
}
?>
        <title>Mr.H解析系统</title>
	</head>
    <body>
    </body>
</html>