<?php
/* *
 * 配置文件
 */
 /*数据库配置*/
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'www_98dou_com', //数据库用户名
	'pwd' => 'LjLwbbTajAEK4x4N', //数据库密码
	'dbname' => 'www_98dou_com' //数据库名
);
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
//商户ID
$alipay_config['partner']		= '1002';

//商户KEY
$alipay_config['key']			= 'wJGRovgUY1zR17Tprp8YVutR0YOZRqGo';


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑


//签名方式 不需修改
$alipay_config['sign_type']    = strtoupper('MD5');

//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');

//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']    = 'http';

//支付API地址
$alipay_config['apiurl']    = 'http://www.a8ku.cn/';
?>