 <?php
        session_start();
        $out_trade_no=1;
        $paytype=$_GET['type'];
        if($paytype=="yecz"){
            $title="账号余额充值结果";
            $taocanbuys="余额充值成功";
        }
        $name=1;
        $money=1;
        $user=$_SESSION['loginusername'];
        $price=$_SESSION['price'];
		$type=$_SESSION['type'];
		$counts=$_SESSION['counts'];
		$finishtime=$_SESSION['finishtime'];
		$tcname=$_SESSION['tcname'];
	    $taocanbuy=$_SESSION['taocanbuy'];

		if($type==1){
		    //点数
		   $tcname=$tcname."_".$counts."点数";
		}else{
		    //时间
		}
		if($taocanbuy==1){
		        unset($_SESSION['taocanbuy']);
		        unset($_SESSION['price']);
		        unset($_SESSION['type']);
		        unset($_SESSION['counts']);
		        unset($_SESSION['tcname']);
		    
		}else{
		   // header("refresh:0;url=../../user/");
		}
		//	header("refresh:2;url=../../user/");
	
        ?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Language" content="zh-cn">
    <meta name="apple-mobile-web-app-capable" content="no"/>
    <meta name="apple-touch-fullscreen" content="yes"/>
    <meta name="format-detection" content="telephone=no,email=no"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="white">
    <meta name="renderer" content="webkit"/>
    <meta name="force-rendering" content="webkit"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1"/>
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-control" content="no-cache">
    <meta http-equiv="Cache" content="no-cache">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title><?php echo $title ?></title>
    <link href="pay/css/wechat_pay.css" rel="stylesheet" media="screen">
    <script src="pay/js/jquery.min.js"></script>
    <style>
        .text-success {
            color: #468847;
            font-size: 2.33333333em;
        }
        .text-fail {
            color: #ff0c13;
            font-size: 2.33333333em;
        }
        .text-center {
            text-align: center;
        }
        .text-left {
            text-align: left;
        }
        .error {

            display: block;
            padding: 9.5px;
            margin: 0 0 10px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #333;
            word-break: break-all;
            word-wrap: break-word;
            background-color: #f5f5f5;
            border: 1px solid #ccc;
            border-radius: 4px;

        }
    </style>
</head>

<body>
<div class="body" id="body">
    <h1 class="mod-title">
        <span class="ico_log ico-2" v-if="payType == 3"></span>
        <span class="ico_log ico-1" v-if="payType == 2"></span>
        <span class="ico_log ico-3" v-if="payType == 1"></span>
    </h1>

    <div class="mod-ct">
        <div class="order">
        </div>
       
        <div class='error text-left'><h1 class="text-center text-success"><?php echo $taocanbuys; ?></h1><!--fail-success--></div>
        <div class="detail detail-open" style="display: block;">
            <dl class="detail-ct" id="desc" >
                <dt>购买者：</dt>
                <dd><?php echo $user?></dd>
                <dt>支付方式：</dt>
                <dd>账号余额</dd>
                <dt>商品名称：</dt>
                <dd><?php echo $tcname?></dd>
                <dt>订单金额：</dt>
                <dd><?php echo $price?> 元</dd>
            </dl>


        </div>

        <div class="tip-text">
        </div>
        
        <?php
        if($taocanbuy==1){
	        echo '<div class=\'error text-left\'><h3 class="text-center text-success" style="font-size:24px">用户：'.$user.'成功充值'.$counts.'点数<br>正在转跳中，请稍等...</h3></div>';
	    }else if($taocanbuy==2){
	         echo '<div class=\'error text-left\'><h3 class="text-center text-success" style="font-size:24px">用户：'.$user.',你的余额已不足，请充值<br>正在转跳中，请稍等...</h3><!--fail-success--></div>';
	    }
	    else{
	          echo '<div class=\'error text-left\'><h3 class="text-center text-success" style="font-size:24px">用户：'.$user.'充值失败<br>正在转跳中，请稍等...</h3><!--fail-success--></div>';
	    }
        
        ?>
        
 
                <br />

    </div>
    <div class="foot">
        <div class="inner">
            <p>如有问题，请联系客服</p>
            <p>本站源码由<a href="//www.a8ku.cn/" target="_blank" style="color:#5FB878">Mr.H</a>提供技术服务支持</p>
        </div>
    </div>

</div>

<script src="./js/vue.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery@1.11.3"></script>
<script src="https://lib.baomitu.com/layer/3.1.1/layer.js"></script>

</body>
</html>