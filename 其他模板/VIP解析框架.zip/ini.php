<?php
//版权：开发者
//作者：开发者
//网址：kaifazhe.org.cn

  $ini = array(
  'title'=>'VIP视频解析专用',//网站标题
  'keywords'=>'VIP视频解析,VIP视频解析站,影视会员解析',//网站关键字
  'description'=>'VIP视频解析专为用户提供各大影视网站会员视频解析服务。',//网站描述
  'kfqq'=>'1694841114',//开发者QQ
  );
?>