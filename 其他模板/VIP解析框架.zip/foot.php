<?php
//版权：开发者
//作者：开发者
//网址：kaifazhe.org.cn

?>
<div class="panel-body" style="text-align: center;">
 <div class="container-fluid">
  <a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=384ec3604511cd5d16ece8e967c3989d5288694b68900bdde9574b1766d02095" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-thumbs-up"></span>不会用点我</a>
  <a target="_blank" href="http://vip.kaifazhe.org.cn" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-globe"></span>更多接口后续更新</a> 
 <button type="button" class="btn btn-info btn-sm"><span class="glyphicon glyphicon-user"></span>  <a href="http://www.zzidc.com/main/huodong/registspread/spreadid_80394_hdName_regist2016.html">1元主机支持</a>
 </button> 
<br><span class="copyright">Copyright &copy; 2017 kaifazhe.org.cn  <a href="" target="_blank" title="风沙"> <?php echo $ini['title']?> </a> - Collect from <a href="http://vip.kaifazhe.org.cn/" title="风沙娱乐" target="_blank">开发者站</a></span>
</div>
</body>
</html>